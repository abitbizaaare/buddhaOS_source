# /ancestors

These are the source ancestors.

- `whale.html` - gradient following, resonance, pod coherence.
- `cosmic.html` - particle universe, attractors, fractal/noise drift.
- `abitbizaaare.html` - proto-web / Q@w@rd page energy.

Use them as inspiration. Do not treat them as sacred files. Open them, read the comments, copy a behavior, remix it into your own webpage.
