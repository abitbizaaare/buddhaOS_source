# buddhaOS

A static retro desktop for Q@w@rd / A BIT BIZAARE / Supermerger.

Open `index.html` in a browser. That is the whole boot process.

No frameworks. No build tools. No AI libraries. Just HTML, CSS, and JavaScript.

## What is inside

- `index.html` - the main fake OS desktop
- `system/` - window chrome, boot page, UI JavaScript
- `ancestors/` - whale, cosmic, and abitbizaaare ancestor source
- `apps/` - Supermerger, Creator Kit, Notes
- `docs/` - how-to and philosophy zines

## How to extend

1. Add a new HTML file in `apps/`.
2. Add a new desktop icon in `index.html`.
3. Add a new app entry in `system/ui.js`.
4. Reuse `.window`, `.panel`, `.btn`, and `.codebox` from `system/windows.css`.

The goal is not perfection. The goal is editable source.
