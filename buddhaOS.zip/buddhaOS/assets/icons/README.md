# icons

Place small GIF, PNG, or SVG icons here. Keep them lightweight.
