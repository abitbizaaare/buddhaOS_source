# /apps

Apps are normal HTML files wearing the buddhaOS skin.

- `supermerger.html` explains the merged creator layer.
- `creator-kit.html` is a copyable starting point.
- `notes.html` is a small editable-feeling scratchpad.

To make a new app, duplicate `creator-kit.html`, rename it, and change the content.
