# /system

This folder is the fake kernel of buddhaOS.

- `boot.html` explains the boot layer.
- `windows.css` controls the Win98 / early Linux / BIOS skin.
- `ui.js` controls windows, taskbar buttons, source viewer, boot log, matrix rain, and app switching.

## Modify the look

Edit the CSS variables at the top of `windows.css`.

```css
--green:#00ff66;
--gold:#f0c040;
--panel:#020805;
```

## Add an app

In `ui.js`, add an entry to `APPS`, then add a desktop icon in `index.html` with `data-open="yourAppName"`.
