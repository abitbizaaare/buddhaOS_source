# How to Use buddhaOS

Welcome to the stu.

## Boot

Open `index.html` in any modern browser. You do not need a server for the main desktop.

## Navigate

Click the desktop icons:

- **About OS** explains the purpose.
- **Ancestors** opens a code viewer for whale, cosmic, and abitbizaaare source.
- **Creator Kit** explains how to build your own page.
- **Docs** links to the markdown guides.
- **Boot Log** gives system messages and a weird button.

The taskbar restores open windows.

## Build your own page

1. Open `apps/creator-kit.html`.
2. Save a copy with a new name.
3. Change the text, links, and sections.
4. Keep the CSS link: `../system/windows.css`.
5. Reload the browser after every change.

## Page recipes

### Portfolio

Make sections for work, process, about, and contact.

### Photography page

Make a gallery, rates, booking instructions, and a simple contact button.

### Business landing page

Write the offer, who it helps, proof, and one clear call to action.

### Digital marketing page

Show the campaign goal, assets, message, metrics, and next step.

## Build without AI

Read the source. Change one small thing. Refresh. Learn the cause and effect. That is the OS.
