# BuddhaOS

BuddhaOS is a directory metaphor for organizing a website like a tiny spiritual operating system.

It is not a framework. It is not an AI layer. It is a naming system and design philosophy.

## Directories

- `/kernel/` — core identity, boot notes, rules, constants, source lineage.
- `/env/` — atmosphere, tone, colors, layout, room names, page weather.
- `/agent/` — behavior, interactions, prompts, gates, simulations, click logic.
- `/ui/` — reusable interface pieces: buttons, panels, cards, terminals, readouts.

## Philosophy

Q@W@RD treats the webpage as a classroom turned into a world. The interface is not only decoration; it is instruction. A button teaches. A panel reveals. A passcode creates ritual. A canvas shows motion. A README is a classroom wall.

## How to extend

Create plain text notes in each folder before adding more code. Example:

- Add `kernel/site-rules.md` before adding new sections.
- Add `env/colors.md` before changing colors.
- Add `agent/clicks.js` for new interactions.
- Add `ui/cards.html` for reusable card snippets.

Keep it readable. The next creator should be able to open the folder and understand the world.
