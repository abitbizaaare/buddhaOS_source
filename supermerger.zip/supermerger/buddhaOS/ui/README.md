# buddhaOS/ui

This folder stores the ui layer of the Supermerger.

Use it as a readable place for notes, snippets, and small pure-code files. Keep everything plain HTML, CSS, JS, or Markdown.

No frameworks. No build tools. No AI libraries.
