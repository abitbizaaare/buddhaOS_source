# Ancestors

This folder preserves the source lineage used by the Supermerger.

- `whale.html` — Whale-Mind ancestor: ocean comfort field, gradient following, pod resonance.
- `cosmic.html` — Cosmos-Mind ancestor: particle universe, attractors, fractal noise, drift.
- `abitbizaaare.html` — current Q@W@RD / A BIT BIZAARE page source and visual language.
- `proto-web-gate.html` — early matrix/passcode proto-web gate.

Open these files directly in a browser, then read the source. Copy ideas, not just code.
