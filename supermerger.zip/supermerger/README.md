# SUPERMERGER

A pure HTML/CSS/JS webpage package that merges the proto-web, the Q@W@RD proto-OS aesthetic, the Whale-Mind ancestor, and the Cosmos-Mind ancestor.

Open `index.html` in a browser. No install. No terminal. No build step. No frameworks. No AI libraries.

## Folder map

```text
/supermerger/
  index.html
  README.md
  /buddhaOS/
    README.md
    /kernel/
    /env/
    /agent/
    /ui/
  /ancestors/
    whale.html
    cosmic.html
    abitbizaaare.html
    proto-web-gate.html
  /creator-kit/
    template.html
    style.css
    interactions.js
    README.md
```

## How to use

1. Open `index.html`.
2. Click the ancestor doors.
3. Open `creator-kit/template.html`.
4. Duplicate the creator kit folder for your own project.
5. Replace the copy, cards, buttons, and links.
6. Keep one weird interaction so the page feels alive.

## What this is for

- Portfolios
- Photography pages
- Design showcases
- Business landing pages
- Digital marketing pages
- Creative experiments
- Student/classroom projects

## The stu ethos

A stu is not only a studio. It is a study room, a classroom, a browser tab, a rehearsal space, a shrine to practice, and a weird little world. The visitor should learn by clicking.

## Building without AI

This package is intentionally simple. Learn by editing the source directly. Use comments. Rename variables. Break things. Undo. Try again. You are not outsourcing the page; you are learning the page.
