// Creator Kit interactions: copy, rename, and modify.
// Pure JavaScript. No frameworks. No AI libraries.

const rooms = document.querySelectorAll('.room');

document.querySelectorAll('[data-room]').forEach((button) => {
  button.addEventListener('click', () => {
    const id = button.getAttribute('data-room');
    rooms.forEach((room) => room.classList.remove('active'));
    const room = document.getElementById(id);
    if (room) room.classList.add('active');
  });
});

const weird = document.getElementById('weirdButton');
if (weird) {
  const messages = [
    'the page blinked back',
    'a tiny room opened',
    'the browser became a classroom',
    'signal received',
    'try changing this message in interactions.js'
  ];
  weird.addEventListener('click', () => {
    weird.textContent = messages[Math.floor(Math.random() * messages.length)];
    document.body.classList.add('weird');
    setTimeout(() => document.body.classList.remove('weird'), 900);
  });
}
