# Creator Kit

This is the copy-and-edit starter kit for creators, entrepreneurs, designers, photographers, business owners, and digital marketers.

## Files

- `template.html` — your starter webpage.
- `style.css` — Q@W@RD + abitbizaaare visual system.
- `interactions.js` — small weird browser behaviors.

## Setup

1. Copy the `creator-kit` folder.
2. Rename it to your project name.
3. Open `template.html` in a browser.
4. Edit the text in a code editor.
5. Replace placeholder links with your links.
6. Publish the folder on GitHub Pages, Netlify, your own server, or any static hosting service.

## Customize

- Change the title in `<title>`.
- Change the big hero headline.
- Replace the cards with your projects, services, photos, or campaigns.
- Keep the `data-room` buttons if you want hidden panels.
- Add more rooms by copying a `.room` block.

## Use whale/cosmos as inspiration

The whale ancestor teaches resonance: pages can respond to groups, patterns, comfort, and signal.

The cosmos ancestor teaches motion: pages can feel like a field of particles, attractors, drift, and atmosphere.

You do not need to copy all the math. Copy the idea: small rules create a living world.

## Build without AI

Read one file at a time. Change one thing. Refresh the browser. Repeat. That is the classroom.
